package com.cg.trg.pro;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty","html:html-output"},glue="com.cg.trg.pro" )
public class TestRunner {

}
