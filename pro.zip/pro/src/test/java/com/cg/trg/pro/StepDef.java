package com.cg.trg.pro;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {
	private Customer customer;
	private WebDriver driver;
	List<String> l1=new ArrayList<String>();
	/*@Before
	@Given("^Given check the value given$")
	public void check_the_value_given() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/pro/form1.html");
	}*/
	int i=0;
	@When("^checking value is entered in user text box$")
	public void checking_value_is_entered_in_user_text_box(DataTable arg1) throws Throwable {
	
		l1=arg1.asList(String.class);
	
		for(i=0;i<l1.size();i++)
		{		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/pro/form1.html");
			customer.setName(l1.get(i));
			customer.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}	
	}

	@When("^enter empty value in city text box$")
	public void enter_empty_value_in_city_text_box(DataTable arg1) throws Throwable {
		l1=arg1.asList(String.class);
		for(i=0;i<l1.size();i++)
		{		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/pro/form1.html");
		customer.setName("Ravali");
			customer.setCity(l1.get(i));
			customer.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}	
	}


	@When("^empty value is entered in  password text box$")
	public void empty_value_is_entered_in_password_text_box(DataTable arg1) throws Throwable {
		l1=arg1.asList(String.class);
		for(i=0;i<l1.size();i++)
		{		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/pro/form1.html");
		customer.setName("Ravali");
			customer.setCity("Hyderabad");
			customer.setPassword(l1.get(i));
			customer.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}	
	}

	@When("^enter empty value in gender radio button$")
	public void enter_empty_value_in_gender_radio_button() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/pro/form1.html");
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali@234");
		customer.setStore();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^enter empty value in checking languages$")
	public void enter_empty_value_in_checking_languages() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/pro/form1.html");
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali@234");
		customer.setFemale();
		customer.setStore();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^enter empty value in mynumber field$")
	public void enter_empty_value_in_mynumber_field(DataTable arg1) throws Throwable {
		l1=arg1.asList(String.class);
		for(i=0;i<l1.size();i++)
		{		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/pro/form1.html");
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali@234");
		customer.setFemale();
		customer.setTel();
		customer.setEng();
		customer.setNummber(l1.get(i));
		customer.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}	
	}


	@When("^enter empty value in email field$")
	public void enter_empty_value_in_email_field(DataTable arg1) throws Throwable {

		l1=arg1.asList(String.class);
		for(i=0;i<l1.size();i++)
		{		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/pro/form1.html");
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali@234");
		customer.setFemale();
		customer.setTel();
		customer.setEng();
		customer.setNummber("20");
		customer.setEmail(l1.get(i));
			customer.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}	
	}


	@When("^enter empty value in mobilenumber field$")
	public void enter_empty_value_in_mobilenumber_field(DataTable arg1) throws Throwable {
		l1=arg1.asList(String.class);
		for(i=0;i<l1.size();i++)
		{		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/pro/form1.html");
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali@234");
		customer.setFemale();
		customer.setTel();
		customer.setEng();
		customer.setNummber("20");
		customer.setEmail("ravali@gmail.com");
		customer.setMobile(l1.get(i));
			customer.setStore();
			String alertMessage = driver.switchTo().alert().getText();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			System.out.println("alert :: "+alertMessage);
			Thread.sleep(2000);
			driver.close();
		}	
	}


	@When("^all the details enteres successfully$")
	public void all_the_details_enteres_successfully() throws Throwable {
	
	
	}

	@Then("^return successfull page$")
	public void return_successfull_page() throws Throwable {

	}


}
