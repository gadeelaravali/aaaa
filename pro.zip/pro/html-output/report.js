$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/cg/trg/pro/pro.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    }
  ],
  "line": 3,
  "name": "check the validations for registration page",
  "description": "",
  "id": "check-the-validations-for-registration-page",
  "keyword": "Feature",
  "tags": [
    {
      "line": 2,
      "name": "@tag"
    }
  ]
});
formatter.background({
  "line": 5,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 8,
  "name": "checking username",
  "description": "",
  "id": "check-the-validations-for-registration-page;checking-username",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 7,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 9,
  "name": "checking value is entered in user text box",
  "rows": [
    {
      "cells": [
        "ravali"
      ],
      "line": 10
    },
    {
      "cells": [
        "Ravali"
      ],
      "line": 11
    },
    {
      "cells": [
        "jkfjkf"
      ],
      "line": 12
    },
    {
      "cells": [
        "f"
      ],
      "line": 13
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "StepDef.checking_value_is_entered_in_user_text_box(DataTable)"
});
formatter.result({
  "duration": 36184684946,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 16,
  "name": "checking city",
  "description": "",
  "id": "check-the-validations-for-registration-page;checking-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 17,
  "name": "enter empty value in city text box",
  "rows": [
    {
      "cells": [
        "jksdfg89"
      ],
      "line": 18
    },
    {
      "cells": [
        "hyderabad"
      ],
      "line": 19
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_city_text_box(DataTable)"
});
formatter.result({
  "duration": 18002660926,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 20,
  "name": "checking password",
  "description": "",
  "id": "check-the-validations-for-registration-page;checking-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "empty value is entered in  password text box",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "print error message for password field",
  "rows": [
    {
      "cells": [
        "hgf"
      ],
      "line": 23
    },
    {
      "cells": [
        "ravali876@"
      ],
      "line": 24
    },
    {
      "cells": [
        "gh"
      ],
      "line": 25
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.empty_value_is_entered_in_password_text_box(DataTable)"
});
formatter.result({
  "duration": 274462,
  "error_message": "cucumber.runtime.CucumberException: Arity mismatch: Step Definition \u0027com.cg.trg.pro.StepDef.empty_value_is_entered_in_password_text_box(DataTable) in file:/C:/D%20Drive/programsspring/pro/target/test-classes/\u0027 with pattern [^empty value is entered in  password text box$] is declared with 1 parameters. However, the gherkin step has 0 arguments []. \nStep: When empty value is entered in  password text box\r\n\tat cucumber.runtime.StepDefinitionMatch.arityMismatch(StepDefinitionMatch.java:102)\r\n\tat cucumber.runtime.StepDefinitionMatch.transformedArgs(StepDefinitionMatch.java:60)\r\n\tat cucumber.runtime.StepDefinitionMatch.runStep(StepDefinitionMatch.java:37)\r\n\tat cucumber.runtime.Runtime.runStep(Runtime.java:300)\r\n\tat cucumber.runtime.model.StepContainer.runStep(StepContainer.java:44)\r\n\tat cucumber.runtime.model.StepContainer.runSteps(StepContainer.java:39)\r\n\tat cucumber.runtime.model.CucumberScenario.run(CucumberScenario.java:44)\r\n\tat cucumber.runtime.junit.ExecutionUnitRunner.run(ExecutionUnitRunner.java:102)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:63)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:18)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.runtime.junit.FeatureRunner.run(FeatureRunner.java:70)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:95)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:38)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.api.junit.Cucumber.run(Cucumber.java:100)\r\n\tat org.eclipse.jdt.internal.junit4.runner.JUnit4TestReference.run(JUnit4TestReference.java:86)\r\n\tat org.eclipse.jdt.internal.junit.runner.TestExecution.run(TestExecution.java:38)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:538)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:760)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.run(RemoteTestRunner.java:460)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.main(RemoteTestRunner.java:206)\r\n",
  "status": "failed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 27,
  "name": "checking gender",
  "description": "",
  "id": "check-the-validations-for-registration-page;checking-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "enter empty value in gender radio button",
  "keyword": "When "
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_gender_radio_button()"
});
formatter.result({
  "duration": 9047637803,
  "status": "passed"
});
formatter.background({
  "line": 5,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 31,
  "name": "checking known languages",
  "description": "",
  "id": "check-the-validations-for-registration-page;checking-known-languages",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 32,
  "name": "enter empty value in checking languages",
  "keyword": "When "
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_checking_languages()"
});
