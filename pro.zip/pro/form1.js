function chkEmpty(){
	
	var name=/[A-Z]{1}[a-z]+/;
	//var city=/[Hyderabad][Chennai][Delhi][Pune]/;
	var city=/^[a-zA-Z]+$/;
	var password=/^([a-zA-Z0-9@*#]{8,15})$/;
	var mob = /^[7-9]{1}[0-9]{9}$/;
	var mynumber=/^[0-9]{2}$/;
	var email=/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;

    if(!name.test(document.forms["form1"]["userName"].value)){
       alert("Username should start with caps!");
    }
    else  if(!city.test(document.forms["form1"]["city"].value)){
       alert("city should not have numbers!");
    }
    else  if(!password.test(document.forms["form1"]["password"].value)){
        alert("password should be between 8-15 letters!");
     }
    else if( document.forms["form1"]["gender"].value=="")
    	{
    	 alert("gender should be entered!");
    	}
    else if(document.getElementById("eng").checked==false && document.getElementById("tel").checked==false && document.getElementById("tam").checked==false)
	{
	 alert("languages should be entered!");
	}
   /* else if( document.from1.hiddentype.value=="")
	{
	 alert("hidden should be entered!");
	}*/
    else if(!mynumber.test(document.forms["form1"]["mynumber"].value))
	{
	 alert("mynumber should be between 01-99!");
	}
    else if( !email.test(document.forms["form1"]["emailname"].value))
	{
	 alert("email should be in proper format!");
	}
    else if( !mob.test(document.forms["form1"]["mobile"].value))
	{
	 alert("mobile should start with 7,8,9 and should have 10 digits!");
	}
    else
    	{
    	alert("completed successfully");
    	window.location="success.html";
    
    	}
}

