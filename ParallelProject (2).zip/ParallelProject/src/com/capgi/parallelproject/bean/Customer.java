package com.capgi.parallelproject.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="customer_bank")
public class Customer implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer accountNo=(int)(Math.random()*100000 + 1111100000L);
	private int pin=(int)(Math.random()*9000)+1000;
	@Column(nullable=false)
	private String customerFirstName;
	private String customerMiddleName;
	@Column(nullable=false)
	private String customerLastName;
	@Column(nullable=false)
	private String age;
	@Column(nullable=false)
	private String address;
	private String mobileNo;
	@Column(nullable=false)
	private String accountType;
	@Column(nullable=false)
	private double Balance;
	@Column(nullable=false)
	private String gender;
	private String email;
	@Column(nullable=false)
	private String govtId;
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private List<Transaction> transactions = new ArrayList<Transaction>();
	
	public String getGovtId() {
		return govtId;
	}
	public void setGovtId(String govtId) {
		this.govtId = govtId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double openingBalance) {
		this.Balance = openingBalance;
	}
	public Integer getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Integer accountNo) {
		this.accountNo = accountNo;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getCustomerFirstName() {
		return customerFirstName;
	}
	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}
	public String getCustomerMiddleName() {
		return customerMiddleName;
	}
	public void setCustomerMiddleName(String customerMiddleName) {
		this.customerMiddleName = customerMiddleName;
	}
	public String getCustomerLastName() {
		return customerLastName;
	}
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
	public void addTransaction(Transaction transaction) {
		transaction.setCustomer(this);			//this will avoid nested cascade
		this.getTransactions().add(transaction);
	}
	public Customer(){}
	
	public Customer(int accountNo, int pin, String customerFirstName,
			String customerMiddleName, String customerLastName, String age,
			String address, String mobileNo, String accountType,
			double balance, String gender, String email, String govtId) {
		super();
		this.accountNo = accountNo;
		this.pin = pin;
		this.customerFirstName = customerFirstName;
		this.customerMiddleName = customerMiddleName;
		this.customerLastName = customerLastName;
		this.age = age;
		this.address = address;
		this.mobileNo = mobileNo;
		this.accountType = accountType;
		Balance = balance;
		this.gender = gender;
		this.email = email;
		this.govtId = govtId;
	}
	@Override
	public String toString() {
		return "Customer [accountNo=" + accountNo + ", pin=" + pin
				+ ", customerFirstName=" + customerFirstName
				+ ", customerMiddleName=" + customerMiddleName
				+ ", customerLastName=" + customerLastName + ", age=" + age
				+ ", address=" + address + ", mobileNo=" + mobileNo
				+ ", accountType=" + accountType + ", Balance=" + Balance
				+ ", gender=" + gender + ", email=" + email + ", govtId="
				+ govtId + "]";
	}
	
	
}
