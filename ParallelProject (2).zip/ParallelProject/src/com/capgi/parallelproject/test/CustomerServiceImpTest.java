package com.capgi.parallelproject.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgi.parallelproject.bean.Customer;
import com.capgi.parallelproject.exception.CustomerNotFound;
import com.capgi.parallelproject.service.CustomerServiceImp;

public class CustomerServiceImpTest extends CustomerServiceImp {

	Customer c=new Customer();
	Customer b=new Customer();
	CustomerServiceImp a=new CustomerServiceImp();
	
	@Test
	public void testCreateAccount() throws CustomerNotFound {
		assertNotNull(a.createAccount(c));
	}

	@Test
	public void testShowBalance() throws CustomerNotFound {
		assertEquals(c.getBalance(), a.showBalance(c.getAccountNo(), c.getPin()));
	}

	@Test
	public void testDeposit() throws CustomerNotFound {
		double deposit=c.getBalance();
		assertEquals(c.getBalance(), a.deposit(c,c.getAccountNo(),c.getPin(), deposit));
	}

	@Test
	public void testWithDraw() throws CustomerNotFound {
		double withDraw=c.getBalance();
		assertEquals(c.getBalance(), a.withDraw(c,c.getAccountNo(),c.getPin(), withDraw));
	}

	@Test
	public void testFundTransfer() throws CustomerNotFound {
		double amount=c.getBalance();
		assertNotNull(a.fundTransfer(c, b, amount, c.getAccountNo(), b.getAccountNo(), c.getPin()));
	}

	@Test
	public void testPrintTransaction() {
		assertNotNull(c);
	}

}
