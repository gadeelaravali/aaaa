package com.capg.cms.ui;
import java.util.Scanner;
import com.capg.cms.beans.Customer;
import com.capg.cms.exception.CustomerNotFound;
import com.capg.cms.service.CustomerServiceImp;
public class Client {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerServiceImp service = new CustomerServiceImp();
		while (true) {
			System.out.println("WELCOME TO CUSTOMER MANAGMENT");
			System.out.println("-------------------------------------");
			System.out.println("1.ADD CUSTOMER");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT AMOUNT");
			System.out.println("4.WITHDRAW AMOUNT");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTIONS");
			System.out.println("7.EXIT");
			System.out.println("-------------------------------------");
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				/*System.out.println("ENTER ACCOUNT NUMBER");
				int accno = sc.nextInt();*/
				System.out.println("ENTER CUSTOMER NAME");
				String cname = sc.next();
				System.out.println("ENTER CUSTOMER MOBILENO");
				String mobileno = sc.next();
				System.out.println("ENTER CUSTOMER PANNO");
				String panno = sc.next();
				System.out.println("ENTER CUSTOMER AGE");
				int age = sc.nextInt();
				System.out.println("ENTER CUSTOMER ADDR");
				StringBuffer addr = new StringBuffer();
				System.out.println("ENTER HOUSE NO");
				StringBuffer addr1 = new StringBuffer();
				//String s = addr.next();
				//addr.append(sc.next());
				addr1.append(sc.next());
				System.out.println("ENTER STREET NAME");
				StringBuffer addr2 = new StringBuffer();
				addr2.append(sc.next());
				System.out.println("ENTER CITY NAME");
				StringBuffer addr3 = new StringBuffer();
				addr3.append(sc.next());
				System.out.println("ENTER STATE NAME");
				StringBuffer addr4 = new StringBuffer();
				addr4.append(sc.next());
				System.out.println("ENTER PINCODE");
				StringBuffer addr5 = new StringBuffer();
				addr5.append(sc.next());			
				addr.append(","+addr1).append(","+addr2).append(","+addr3).append(","+addr4);
				System.out.println("ENTER BALANCE"); 
				 int amt = sc.nextInt();
				Customer bean = new Customer(cname,addr,amt,mobileno,age,panno);
				/*bean.setMobileno(mobileno);
				bean.setAge(age);
				bean.setPanno(panno);
				bean.getAccno();
				bean.setAddr(addr);
				bean.setCname(name);*/
				// bean.setAmt(amt);
				 //boolean isValid = service.validateData(bean);
				//String phno = sc.next();
				/*boolean isvalid = service.validateAccno(accno);
				if (isvalid) {*/
					boolean validname = service.validateName(cname);			
						boolean validphno = service.validatePhno(mobileno);	
						boolean validage = service.validateAge(age);	
						boolean validpan = service.validatePan(panno);
						//boolean validAddr = service.validateAddr(addr);
							boolean isAdded = service.addCustomer(bean);
							if (validname && validphno && isAdded && validage && validpan /*&&validAddr*/) 
							{
								System.out.println("added successfully");
								System.out.println(bean);
							} else
								System.out.println("not added");
							break;
			case 2:
				System.out.println("ENTER ACCNO TO GET BALANCE");
				int id1 = sc.nextInt();				
				if(id1!=0)
				{
				boolean validaccno = service.validateAccno(id1);
				if (validaccno) {	
					System.out.println("ENTER PIN");
					int id2=sc.nextInt();
					boolean validpinno = service.validatePinno(id2);
					if(validpinno)
					{									
				Customer c = service.displayCustomer(id1,id2);
				//	service.displayCustomer(id);
				//	c=service.displayCustomer(id1,id2))
						//System.out.println(c);
					}
				}
				else
				{
					System.out.println("enter valid pin no");
				}
				}
				
				else {	System.out.println("enter valid accno");
						try {
							throw new CustomerNotFound();
						} catch (CustomerNotFound e) {
							// TODO: handle exception
							e.printStackTrace();
					//	}					
					}			
				}
				break;							/*	}
						
					else System.err.println("plz enter correct data");*/						  
				/*	}						 
						else
							System.out.println("invalid mobile num");
					} else
						System.out.println("invalid name");*/
				/*}else
					System.out.println("invalid account num");					
					}				
				break;	*/		
			  case 3: System.out.println("ENTER ACCNO TO WITHDRAW");
				int id3 = sc.nextInt();				
				if(id3!=0)
				{
				boolean validaccno = service.validateAccno(id3);
				if (validaccno) {	
					System.out.println("ENTER PIN");
					int id4=sc.nextInt();
					boolean validpinno = service.validatePinno(id4);
					if(validpinno)
					{	
				  System.out.println("amount to withdraw");
				  int wd = sc.nextInt();	
				  Customer c = service.withDraw(id3,id4,wd);
				  System.out.println("withdrawn successfully");
			/*	  int a=c.getAmt();
				  System.out.println("balance is:"+a);*/
			//	  Customer c1= service.withDraw(id3,id4);
					}
				}
				}
			  break;
			  /*case 4:
			  System.out.println("deposit amount"); service.depositAmount();
			  break; case 5: System.out.println("display balance");
			  service.displayBalance(); break; case 6:
			  System.out.println("print transactions");
			 service.printTransactions(); break; case 7: System.exit(0);
			 break;
				}*/
			default:
			/*	System.out.println("displayig all details");
				service.displayAll();*/
				break;
		}
	
	}

}
}
