package com.capg.cms.dao;
import java.util.HashMap;
import java.util.Iterator;
/*import java.util.List;
import java.util.ArrayList;*/
import java.util.Map;
import java.util.Set;

import com.capg.cms.beans.Customer;
public class CustomerDAOImp implements ICustomerDAO {
	Map<Integer,Customer> custList=new HashMap<Integer,Customer>();		
	//Customer a=new Customer(null,null,0,null,0,null);
	//static List<Customer> custList = new ArrayList<Customer>();
	@Override
	public boolean addCustomer(Customer c) {
		// TODO Auto-generated method stub
		/*Boolean isAdded = false;
		 isAdded = custList.add(c);
		//Math.random();
		return isAdded;//return custList.add(c);	
*/
	int key=c.getAccno();
	custList.put(key,c);
	return custList.containsValue(c);	
	}
	@Override
	public boolean validateAccno(int id1) {
	boolean flag=false;
		for (Customer c:custList.values()) {
			if((c.getAccno()==id1))
	//	if(ca.getAccno()==accno)
		flag=true;
		}
		return flag;
	}
	@Override
	public boolean validatePinno(int id2) {
	boolean flag=false;
		for (Customer c:custList.values()) {
			if((c.getPin()==id2))
	//	if(ca.getAccno()==accno)
		flag=true;
		}
		return flag;
	}
	
	public Customer displayCustomer(int id1,int id2) {
		/*// TODO Auto-generated method stub
		Set set = custList.entrySet();
		// Get an iterator
		Iterator i = set.iterator();
		// Display elements	
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();	
		int c=(int)me.getKey();
		Customer d= (Customer) me.getValue();
			System.out.println(c + ": " +d);}	*/		
	Customer cust=null;
	for(Customer c:custList.values())
	{
		if((c.getAccno()==id1)&&(c.getPin()==id2))
		{
		System.out.println("Balance is:"+c.getAmt());	
		}
	}
	return cust;
	}
	/*public void displayAll()
	{
		Iterator<Customer> it = custList.iterator();
	while(it.hasNext()){
		Customer c = it.next();
		System.out.println(c + " ");
	}		
	}*/
	public Customer withDraw(int accno,int pinno,int wd) {
		// TODO Auto-generated method stub
		Customer cust=null;
		for(Customer c:custList.values())
		{			
		if((c.getAmt()>wd))
		{
		int bal=0;
		bal=c.getAmt()-wd;
		c.setAmt(bal);
		System.out.println("balance is"+c.getAmt());
		}
		}			
		return cust;
	}
	public boolean depositAmount(Customer c) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean printTransactions(Customer c) {
		// TODO Auto-generated method stub
		return false;
	}
	

	
	
}
