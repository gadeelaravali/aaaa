package com.capg.cms.service;

import com.capg.cms.beans.Customer;

public interface ICustomerService {

	
   public boolean addCustomer(Customer c);
  public Customer displayCustomer(int accno,int pinno); 
   public	Customer withDraw(int accno,int pinno,int wd);
   public boolean depositAmount(Customer c);
   public boolean printTransactions(Customer c) ; 

	public boolean validateAccno(int accno);
	public boolean validatePinno(int pinno);
	
	
	
	
	
}
