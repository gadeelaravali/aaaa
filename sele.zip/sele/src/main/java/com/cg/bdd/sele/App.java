package com.cg.bdd.sele;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.RefreshPage;


public class App 
{
    public static void main( String[] args )
    {
    	
/*    	System.setProperty("webdriver.chrome.driver", "D:\\drivers\\chromedriver.exe");*/
   /* 	WebDriver wd= new ChromeDriver();
     wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
     
     wd.manage().timeouts().implicitlyWait(5,TimeUnit.MINUTES);*/
     
/*  System.out.println( wd.getTitle());  */
/*  System.out.println(wd.getPageSource());
  System.out.println(wd.getCurrentUrl());
//wd.navigate().refresh();
  WebElement search3 = wd.findElement(By.name("q"));
 
  WebElement search4 = wd.findElement(By.id("gsr"));
  search3.sendKeys("capgemini");

  WebElement search = wd.findElement(By.className("gLFyf"));
  search.sendKeys("capgemini");
  */
/*  WebElement name = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/input"));
  name.sendKeys("Anil");
  WebElement password = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input"));
  password.sendKeys("secret");
  WebElement gender = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[1]"));
  gender.click();
  WebElement mobile = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[4]/td[2]/input"));
  mobile.sendKeys("9900990080");
  WebElement age = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/input"));
  age.sendKeys("22");
  WebElement panno = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[6]/td[2]/input"));
  panno.sendKeys("ABCD7654F");
  WebElement state = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td[2]/input[1]"));
  state.click();
  WebElement state2 = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td[2]/input[2]"));
  state2.click();
  WebElement account = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[8]/td[2]/select/option[2]"));
  account.click();
  WebElement amount = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/input"));
  amount.sendKeys("2000");
  WebElement submit = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td/input"));
  submit.click();*/
  

	// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\drivers\\chromedriver.exe");
	    	WebDriver driver=new ChromeDriver();
	    	
	/*		File pathToBinary = new File("C:/Program Files/Mozilla Firefox/firefox.exe");
			FirefoxProfile firefoxProfile = new FirefoxProfile();
			FirefoxBinary binary = new FirefoxBinary(pathToBinary);
					
			WebDriver driver = new FirefoxDriver(binary,firefoxProfile);
			*/
			driver.get("file:///C:/D%20Drive/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
			
			String parentWindow = driver.getWindowHandle().toString();
			/*WebElement namewd = driver.findElement(By.name("name")); 
			System.out.println("Printing " + getAttribute("id"));*/

			driver.findElement(By.linkText("submit")).click();
			driver.switchTo().window("PopupWindow");
		//	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			driver.close();
			
			driver.switchTo().window(parentWindow);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			//driver.close(); 
/*  
  
WebElement search1 = wd.findElement(By.linkText("Chennai"));
search1.click();
wd.navigate().back();
WebElement search2 = wd.findElement(By.partialLinkText("C"));
search2.click();
wd.navigate().back();

*/

//search1.sendKeys("hello");
//  wd.manage().timeouts().implicitlyWait(2,TimeUnit.MINUTES);
/*  wd.close();*/
  //wd.quit();
  
  
    }
}

  // when we use this if we open new tab its not getting closed it doesn't close all the operations of driver.Only that operation will get closed. 

   //when i use quit then all tabs will get closed.All the operations managed by driver will be closed.
     

