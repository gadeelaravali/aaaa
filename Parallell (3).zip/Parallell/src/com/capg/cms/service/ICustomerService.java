package com.capg.cms.service;

import com.capg.cms.beans.Customer;
import com.capg.cms.exception.CustomerNotFound;

public interface ICustomerService {

	
   public boolean addCustomer(Customer c) throws CustomerNotFound;
  public int displayCustomer(int accno,int pinno) throws CustomerNotFound; 
  public Customer displayCust(int accno);
   public	int withDraw(Customer c1,int wd) throws CustomerNotFound;
   public int depositAmt(int da,Customer c) throws CustomerNotFound;
   public Customer printTransaction(Customer c) ; 

	public boolean validateAccno(int accno) throws CustomerNotFound;
	public boolean validatePinno(int accno,int pinno) throws CustomerNotFound;
	public boolean fundTransfer(Customer c,Customer b,int amt,int accno1,int accno2,int pinno) throws CustomerNotFound;
	
	public Customer printTransactions(int cid,int pinno);
	
	
}
