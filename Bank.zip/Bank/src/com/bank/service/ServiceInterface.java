package com.bank.service;

import com.bank.bean.Customer;

public interface ServiceInterface {
public boolean  addCustomer(Customer c);
public int withDraw(Customer c,int withdraw);
public boolean validAccountNo(String email,int accNumber,int pin);
public boolean validateAmount(int withdraw);
public int showBalance(int accNumber1);
public int deposit(Customer c,int deposit);
   
}
