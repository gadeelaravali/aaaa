package com.bank.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.bank.bean.Customer;
import com.bank.dao.DaoImpl;

public  class ServiceImp implements ServiceInterface  {
	
	DaoImpl dao=new DaoImpl();
	
public boolean validateDate(Customer c) {
		boolean flag=false;
		Pattern p=Pattern.compile("A-Za-z");
		Matcher m=p.matcher(c.getName());
		 boolean a=m.matches();
		 Pattern p1=Pattern.compile("[1-9][0-9]{9}");
			Matcher m1=p1.matcher(c.getPhoneNumber());
			 boolean b =m1.matches();
			Pattern p3=Pattern.compile("hyd");
				Matcher m3=p3.matcher(c.getAddress());
				 boolean d=m3.matches();
		// TODO Auto-generated method stub
		 if(a&&b&&d){
			  flag=true;
		 }
		 return flag;
	}





	public int withDraw(Customer c,int withdraw) {
		// TODO Auto-generated method stub
		int wblance=0;
	if(c.getCurrBal()-withdraw>500)
	{
		wblance=(int) (c.getCurrBal()-withdraw);
		
		
		
		
	}
	return dao.withDraw(c,wblance);
	}

	@Override
	public boolean addCustomer(Customer c) {
		// TODO Auto-generated method stub
		return dao.addCustomer(c);
	}





	public int deposit(Customer c,int deposit) {
		// TODO Auto-generated method stub
		int de=0;
		if(deposit>0)
		{
			de=(int) (c.getCurrBal()+deposit);
			c.setCurrBal(de);
			return dao.deposit(c,de);
		}
		
		return de ;
	}
	





	public boolean validAccountNo(String email,int accNumber,int pin)
	{
	return	dao.validAccountNo(email,accNumber,pin);
		// TODO Auto-generated method stub
		
	}
	public boolean validateAmount(int withdraw)
	{
		return dao.validateAmount(withdraw);
	}









	@Override
	public int showBalance(int accNumber1) {
		// TODO Auto-generated method stub
		return dao.showBalance(accNumber1);
	}
	}
