package com.cg.trg.cal;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^Homepage$")
	public void homepage() throws Throwable {
System.out.println("in login");
	}

	@Given("^Username and password$")
	public void username_and_password() throws Throwable {
System.out.println("username and pasword given");
	}

	@When("^valid$")
	public void valid() throws Throwable {
System.out.println("verified");
	}

	@Then("^return user profile$")
	public void return_user_profile() throws Throwable {
System.out.println("user profile");
	}

}
