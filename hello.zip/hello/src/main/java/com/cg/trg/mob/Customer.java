package com.cg.trg.mob;

public class Customer {

	private int accno = (int)(Math.random()*9000000)+10000000;
	private String cname;
	private String addr;
	private double amt;
	private String mobileno;
	private int age;
	private String panno;

	private int pin=(int)(Math.random()*900)+100;
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public Customer(String cname,String addr, double amt,
			String mobileno, int age, String panno) {
		this.cname=cname;
		this.addr=addr;
		this.amt=amt;
		this.mobileno=mobileno;
		this.age=age;
		this.panno=panno;		
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPanno() {
		return panno;
	}
	public void setPanno(String panno) {
		this.panno = panno;
	}
	public double getAmt() {
		return amt;
	}
	public void setAmt(double amt2) {
		this.amt = amt2;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}

	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	@Override
	public String toString() {
		return "Customer [accno=" + accno + ", cname=" + cname + ", addr="
				+ addr + ", amt=" + amt + ", mobileno=" + mobileno + ", age="
				+ age + ", panno=" + panno + ", pin=" + pin + "]";
	}
	public Customer() {
		super();
	}

	
	
}
