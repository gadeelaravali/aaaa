package com.cg.trg.hello;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {


@When("^I enter a variable (\\d+)$")
public void i_enter_a_variable(int arg1) throws Throwable {
System.out.println("variable1:"+arg1);

}

@When("^I enter an other variable (\\d+)$")
public void i_enter_an_other_variable(int arg1) throws Throwable {
	System.out.println("variable2: "+arg1);
}

@Then("^add  (\\d+) and (\\d+)$")
public void add_and(int arg1, int arg2) throws Throwable {
System.out.println("addition"+(arg1+arg2));
}

@Then("^subtract (\\d+) and (\\d+)$")
public void subtract_and(int arg1, int arg2) throws Throwable {
	System.out.println("subtraction"+(arg1-arg2));
}

@Then("^multiply (\\d+) and (\\d+)$")
public void multiply_and(int arg1, int arg2) throws Throwable {
	System.out.println("multiplication"+(arg1*arg2));
}

@Then("^divide (\\d+) and (\\d+)$")
public void divide_and(int arg1, int arg2) throws Throwable {

	System.out.println("divide:"+(arg1/arg2)); 
}
@When("^I enter a variable -(\\d+)$")
public void i_enter_a_variable1(int arg1) throws Throwable {
	System.out.println("variable1:"+(-arg1));
}

@Then("^add -(\\d+) and (\\d+)$")
public void add_and1(int arg1, int arg2) throws Throwable {
	System.out.println("addition"+(-arg1+arg2));
}




}

