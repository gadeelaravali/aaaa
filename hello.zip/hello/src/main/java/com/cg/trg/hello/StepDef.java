package com.cg.trg.hello;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^Enter mobile number$")
	public void enter_mobile_number() throws Throwable {
	  System.out.println("Enter mobile number");
	}

	@When("^it is enetered$")
	public void it_is_enetered() throws Throwable {
	 System.out.println("mobile number entered");
	}

	List<String> l1=new ArrayList<String>();
	@Then("^validate mobile number$")
	public void validate_mobile_number(DataTable arg1) throws Throwable {
	   l1=arg1.asList(String.class);
/*		Pattern mobileNo=Pattern.compile("^[6-9][0-9]{9}$"); */
	/*	int i=0;
		
		for(i=0;i<l1.size();i++)
		for (String string : l1) 		
		{Matcher mobileMatch=mobileNo.matcher(l1.get(i));
			List<String> results = matcherStream(mobileNo.matcher(mobileMatch))
                    .collect(Collector.l1);
		
		if(mobileMatch.matches())
		{   System.out.println(l1.get(i));
	   System.out.println("validated");
	
		}*/	
	   Predicate<String> mobilePattern = Pattern.compile("^[6-9][0-9]{9}$").asPredicate();	
		  List<String> validList = l1
                .stream()
                .filter(mobilePattern)
                .collect(Collectors.toList());		 
		//  validList.forEach(System.out::println); 
		
	int i=0;
	for(i=0;i<l1.size();i++)
	{		
		//if(validList.get(i)==l1.get(i))
		if(validList.contains(l1.get(i)))
		{ 
			System.out.println(l1.get(i));
			System.out.println("valid");
		/*  
		else	{  System.out.println(l1.get(i));
			System.out.println("enter a mobile number which strats with 6 or 7 or 8 or 9");
	}*/}
		else
		{
			System.out.println(l1.get(i));
			System.out.println("invalid");
		}
		}
	}
}
	
	
		 



