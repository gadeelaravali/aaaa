package com.cg.trg.balance;

import java.util.Scanner;

import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {
	CustomerPro customer= new CustomerPro();
	Scanner s= new Scanner(System.in);
	@Given("^enter the details of customer$")
	public void enter_the_details_of_customer() throws Throwable {
		System.out.println("enter name");
		customer.setFname(s.next());
		System.out.println("enter last name");
		customer.setLname(s.next());
		System.out.println("enter mobile number");
		customer.setMobile(s.next());
		System.out.println("enter city");
		customer.setCity(s.next());
		System.out.println("enter balance");
		customer.setBalance(s.nextInt());
	}

	
	@When("^check balance is greater than and equal to \"([^\"]*)\"$")
	public void check_balance_is_greater_than_and_equal_to(String arg1) throws Throwable {
		Assert.assertTrue(customer.getBalance()>=500);
	}
	@Then("^print customer details$")
	public void print_customer_details() throws Throwable {
		System.out.println(customer);
	}

	@When("^check balance is less than \"([^\"]*)\"$")
	public void check_balance_is_less_than(String arg1) throws Throwable {
		Assert.assertTrue(customer.getBalance()<500);
	}

	@Then("^error message$")
	public void error_message() throws Throwable {
		
			System.err.println("your balance should be more than 500");
	}


}
