package com.cg.trg.balance;

public class CustomerPro {

	private String fname;
	private String lname;
	private String mobile;
	private String city;
	private int balance;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public CustomerPro() {
	
	}
	public CustomerPro(String fname, String lname, String mobile, String city, int balance) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.mobile = mobile;
		this.city = city;
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Customer [fname=" + fname + ", lname=" + lname + ", mobile=" + mobile + ", city=" + city + ", balance="
				+ balance + "]";
	}
	
	
	
}
