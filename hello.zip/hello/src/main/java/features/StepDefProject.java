package features;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.trg.mob.Customer;

import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefProject {
	
	Customer customer= new Customer();
	Scanner s= new Scanner(System.in);
/*@Before
public void user()
{

	System.setProperty("webdriver.chrome.driver", "D:\\drivers\\chromedriver.exe");
	
 
}*//*
	@Given("^I have to enter name of customer$")
	public void i_have_to_enter_name_of_customer() throws Throwable {
	System.out.println("enter the name");
	
	}
	List<String> l1=new ArrayList<String>();
	@When("^given name is valid name$")
	public void given_name_is_valid_name(DataTable arg1) throws Throwable {
		WebDriver wd= new ChromeDriver();
		 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
		WebElement name = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/input"));
		   l1=arg1.asList(String.class);
		   Predicate<String> namepattern = Pattern.compile("^[A-Z][a-z]+$").asPredicate();	
			  List<String> validList = l1
	                .stream()
	                .filter(namepattern)
	                .collect(Collectors.toList());		 			
		int i=0;
		for(i=0;i<l1.size();i++)
		{		
			if(validList.contains(l1.get(i)))
			{ 
				name.sendKeys(l1.get(i));
				name.clear();
				System.out.println(l1.get(i));
				System.out.println("valid");}
			else
			{
				System.out.println(l1.get(i));
				System.out.println("invalid");
			}
			}
		wd.close();
		 System.out.println("name entered");
	}
	
	@Given("^I have to enter password of customer$")
	public void i_have_to_enter_password_of_customer() throws Throwable {
		System.out.println("enter the password");
	}

	@When("^given name is valid password$")
	public void given_name_is_valid_password(DataTable arg1) throws Throwable {
		WebDriver wd= new ChromeDriver();
		 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
		 WebElement password = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input"));
		l1=arg1.asList(String.class);
		   Predicate<String> passwordpattern = Pattern.compile("^[A-Z][a-z][0-9]+$").asPredicate();	
			  List<String> validList = l1
	                .stream()
	                .filter(passwordpattern)
	                .collect(Collectors.toList());		 			
		int i=0;
		for(i=0;i<l1.size();i++)
		{		
			if(validList.contains(l1.get(i)))
			{ 
				password.sendKeys(l1.get(i));
				password.clear();
				System.out.println(l1.get(i));
				System.out.println("valid");}
			else
			{
				System.out.println(l1.get(i));
				System.out.println("invalid");
			}
			}
		wd.close();
		 System.out.println("password entered");
	}

	@Given("^I have to enter gender of customer$")
	public void i_have_to_enter_gender_of_customer() throws Throwable {
System.out.println("enter gender");
	}

	@Then("^I have to enter mobile number$")
	public void i_have_to_enter_mobile_number() throws Throwable {
		System.out.println("enter mobile number");
	}

	@Then("^I have to enter age$")
	public void i_have_to_enter_age() throws Throwable {
	 System.out.println("enter valid age");
	}

	@When("^it is valid age$")
	public void it_is_valid_age(DataTable arg1) throws Throwable {
		WebDriver wd= new ChromeDriver();
		 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
		 WebElement age = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/input"));
		l1=arg1.asList(String.class);
		   Predicate<String> age1 = Pattern.compile("^(1[89]|[2-9][0-9])$").asPredicate();	
			  List<String> validList = l1
	                .stream()
	                .filter(age1)
	                .collect(Collectors.toList());		 			
		int i=0;
		for(i=0;i<l1.size();i++)
		{		
			if(validList.contains(l1.get(i)))
			{ 
				age.sendKeys(l1.get(i));
				age.clear();
				System.out.println(l1.get(i));
				System.out.println("valid");}
			else
			{
				System.out.println(l1.get(i));
				System.out.println("invalid");
			}
			}	wd.close();
		 System.out.println("age entered");
	}

	@Then("^I have to enter panno$")
	public void i_have_to_enter_panno() throws Throwable {
	System.out.println("enter valid age");
	}

	@Then("^I have to enter state$")
	public void i_have_to_enter_state() throws Throwable {
	  System.out.println("enter your city");
	}

	@When("^address is given$")
	public void address_is_given(DataTable arg1) throws Throwable {
		WebDriver wd= new ChromeDriver();
		 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
		 WebElement state = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td[2]/input[1]"));
		 state.click();

WebElement state2 = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td[2]/input[2]"));
state2.click();
		l1=arg1.asList(String.class);
		   Predicate<String> city = Pattern.compile("^hyderabad|chennai$").asPredicate();	
			  List<String> validList = l1
	                .stream()
	                .filter(city)
	                .collect(Collectors.toList());		 			
		int i=0;
		for(i=0;i<l1.size();i++)
		{		
			if(validList.contains(l1.get(i)))
			{ 
				state.sendKeys(l1.get(i));
				state2.sendKeys(l1.get(i));
				state.clear();
				System.out.println(l1.get(i));
				System.out.println("valid");}
			else
			{
				System.out.println(l1.get(i));
				System.out.println("invalid");
			}
			}
		wd.close();
		 System.out.println("state entered");
	}

	@Then("^I have to enter the type of account$")
	public void i_have_to_enter_the_type_of_account() throws Throwable {
System.out.println("enter type of account");
	}

	@Then("^Enter the minimum amount$")
	public void enter_the_minimum_amount() throws Throwable {
	System.out.println("enter minimum amount");
	}
	

@When("^given name is valid gender$")
public void given_name_is_valid_gender(DataTable arg1) throws Throwable {
	WebDriver wd= new ChromeDriver();
	 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
	 WebElement gender1 = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[1]"));
	  gender1.click();
	String gender=null;
	String female=null;
	String male=null;
if(gender==female && gender == male)
{ 
	gender1.sendKeys(gender);
	gender1.clear();
	System.out.println("valid");}
else
{
	System.out.println("invalid");
}
wd.close();
 System.out.println("gender entered");

}


@When("^it is valid mobile number$")
public void it_is_valid_mobile_number(DataTable arg1) throws Throwable {
	WebDriver wd= new ChromeDriver();
	 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
	  WebElement mobile = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[4]/td[2]/input"));

	l1=arg1.asList(String.class);
	   Predicate<String> mobilepattern = Pattern.compile("^[6-9][0-9]{9}$").asPredicate();	
		  List<String> validList = l1
                .stream()
                .filter(mobilepattern)
                .collect(Collectors.toList());		 			
	int i=0;
	for(i=0;i<l1.size();i++)
	{		
		if(validList.contains(l1.get(i)))
		{ 
			mobile.sendKeys(l1.get(i));
			mobile.clear();
			System.out.println(l1.get(i));
			System.out.println("valid");}
		else
		{
			System.out.println(l1.get(i));
			System.out.println("invalid");
		}
		}
	wd.close();
	 System.out.println("mobile entered");
}

@When("^it is valid panno$")
public void it_is_valid_panno(DataTable arg1) throws Throwable {
	WebDriver wd= new ChromeDriver();
	 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
	 WebElement panno = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[6]/td[2]/input"));
	l1=arg1.asList(String.class);
	   Predicate<String> panno1 = Pattern.compile("^[A-Za-z]{5}\\d{4}[A-Za-z]{1}\"$").asPredicate();	
		  List<String> validList = l1
                .stream()
                .filter(panno1)
                .collect(Collectors.toList());		 			
	int i=0;
	for(i=0;i<l1.size();i++)
	{		
		if(validList.contains(l1.get(i)))
		{ 
			panno.sendKeys(l1.get(i));
			panno.clear();
			System.out.println(l1.get(i));
			System.out.println("valid");}
		else
		{
			System.out.println(l1.get(i));
			System.out.println("invalid");
		}
		}
	wd.close();
	 System.out.println("panno entered");
}

@When("^it is valid account$")
public void it_is_valid_account(DataTable arg1) throws Throwable {
	WebDriver wd= new ChromeDriver();
	 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
	 WebElement account = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[8]/td[2]/select/option[2]"));
	 account.click();
	l1=arg1.asList(String.class);
	   Predicate<String> account1 = Pattern.compile("^savings|current$").asPredicate();	
		  List<String> validList = l1
                .stream()
                .filter(account1)
                .collect(Collectors.toList());		 			
	int i=0;
	for(i=0;i<l1.size();i++)
	{		
		if(validList.contains(l1.get(i)))
		{ 
			account.sendKeys(l1.get(i));
			account.clear();
			System.out.println(l1.get(i));
			System.out.println("valid");}
		else
		{
			System.out.println(l1.get(i));
			System.out.println("invalid");
		}
		}
	wd.close();
	 System.out.println("account entered");
}
	

	@When("^the amount is valid amount$")
	public void the_amount_is_valid_amount(DataTable arg1) throws Throwable {
		WebDriver wd= new ChromeDriver();
		 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
		 WebElement amount = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/input"));
		
		
		l1=arg1.asList(String.class);
		   Predicate<String> amount1 = Pattern.compile("^$").asPredicate();	
			  List<String> validList = l1
	                .stream()
	                .filter(amount1)
	                .collect(Collectors.toList());		 			
		int i=0;
		for(i=0;i<l1.size();i++)
		{		
			if(validList.contains(l1.get(i)))
			{ 
				amount.sendKeys(l1.get(i));
				amount.clear();
				System.out.println(l1.get(i));
				System.out.println("valid");}
			else
			{
				System.out.println(l1.get(i));
				System.out.println("invalid");
			}
			}
		wd.close();
		 System.out.println("amount entered");
	}

	@Given("^valid data$")
	public void valid_data() throws Throwable {
System.out.println("valid data");
	}
	

	@Then("^display account created$")
	public void display_account_created() throws Throwable {
		WebDriver wd= new ChromeDriver();
		 wd.get("file:///D:/programsspring/hello/src/main/java/com/cg/trg/mob/bank.html");
		 WebElement submit = wd.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td/input"));
		 submit.click();
	System.out.println("registered");
	wd.close();
	}*/
	
	
			
}
