$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/cg/trg/balance/balance.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: ravali"
    }
  ],
  "line": 3,
  "name": "checking balance",
  "description": "",
  "id": "checking-balance",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "enter the details of customer",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.enter_the_details_of_customer()"
});
formatter.result({
  "duration": 7288397483,
  "error_message": "java.util.InputMismatchException\r\n\tat java.util.Scanner.throwFor(Scanner.java:864)\r\n\tat java.util.Scanner.next(Scanner.java:1485)\r\n\tat java.util.Scanner.nextInt(Scanner.java:2117)\r\n\tat java.util.Scanner.nextInt(Scanner.java:2076)\r\n\tat com.cg.trg.balance.StepDef.enter_the_details_of_customer(StepDef.java:26)\r\n\tat ✽.Given enter the details of customer(com/cg/trg/balance/balance.feature:5)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 6,
  "name": "checking the balance of customer is greatar than 500",
  "description": "",
  "id": "checking-balance;checking-the-balance-of-customer-is-greatar-than-500",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "check balance is greater than and equal to \"500\"",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "print customer details",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "500",
      "offset": 44
    }
  ],
  "location": "StepDef.check_balance_is_greater_than_and_equal_to(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDef.print_customer_details()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "enter the details of customer",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDef.enter_the_details_of_customer()"
});
formatter.result({
  "duration": 13126296361,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "checking the balance of customer is less than 500",
  "description": "",
  "id": "checking-balance;checking-the-balance-of-customer-is-less-than-500",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 12,
  "name": "check balance is less than \"500\"",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "error message",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "500",
      "offset": 28
    }
  ],
  "location": "StepDef.check_balance_is_less_than(String)"
});
formatter.result({
  "duration": 4942775,
  "error_message": "java.lang.AssertionError: expected [true] but found [false]\r\n\tat org.testng.Assert.fail(Assert.java:96)\r\n\tat org.testng.Assert.failNotEquals(Assert.java:776)\r\n\tat org.testng.Assert.assertTrue(Assert.java:44)\r\n\tat org.testng.Assert.assertTrue(Assert.java:54)\r\n\tat com.cg.trg.balance.StepDef.check_balance_is_less_than(StepDef.java:41)\r\n\tat ✽.When check balance is less than \"500\"(com/cg/trg/balance/balance.feature:12)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDef.error_message()"
});
formatter.result({
  "status": "skipped"
});
});